package com.odazie.simpleblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
